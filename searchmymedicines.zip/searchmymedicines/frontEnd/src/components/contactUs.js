import React, { Component } from 'react';

class contactUs extends Component {
    render() {
        return (
            <div>
                Email id:mayuresh123@gmail.com
                phone number:976586
            </div>
        );
    }
}

export default contactUs;