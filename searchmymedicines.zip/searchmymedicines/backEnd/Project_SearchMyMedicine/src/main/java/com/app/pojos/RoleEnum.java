package com.app.pojos;

public enum RoleEnum {
	ADMIN,PHARMACIST,USER;
}
