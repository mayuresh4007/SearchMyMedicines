package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSearchMyMedicineApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSearchMyMedicineApplication.class, args);
	}

}
