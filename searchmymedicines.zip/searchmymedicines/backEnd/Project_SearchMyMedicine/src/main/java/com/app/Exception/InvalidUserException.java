package com.app.Exception;

public class InvalidUserException extends Exception{

	public InvalidUserException(String msg)
	{
		super(msg);
	}
}
